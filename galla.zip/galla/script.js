const fileInput = document.getElementById('fileInput');
const gallery = document.querySelector('.gallery');

fileInput.addEventListener('change', function() {
  const files = fileInput.files;

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const fileType = file.type.split('/')[0]; // Check if it's an image or video

    if (fileType === 'image') {
      const reader = new FileReader();
      reader.onload = function(e) {
        const image = document.createElement('img');
        image.src = e.target.result;
        gallery.appendChild(image);
      };
      reader.readAsDataURL(file);
    } else if (fileType === 'video') {
      const video = document.createElement('video');
      video.src = URL.createObjectURL(file);
      video.controls = true;
      gallery.appendChild(video);
    }
  }
});
